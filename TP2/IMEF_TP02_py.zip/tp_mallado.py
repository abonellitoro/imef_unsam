
import numpy as np
import matplotlib.pyplot as plt

def mallado(nnod, nelem, nod_x_elem, L, T0, T_L):

    #COMPLETAR!
    
    return coorx, conect, temp_fija, valor_temp_fija




if __name__ == '__main__':

    ndim = 1
    nod_x_elem = 2 # 3; # 4; # 5;
    nelementos = 4 # 5; # 6;
    nnodos = (nod_x_elem-1)*nelementos+1
    L = 4.0
    H_k = 8.0
    T0 = 50.0
    T_L = 10.0

    temperatura = np.zeros((nnodos))

    coorx, conectividad, temp_fija, valor_temp_fija = mallado(nnodos, nelementos, nod_x_elem, L, T0, T_L)

    for i in range(nnodos):
        if (temp_fija[i] == 1):
            temperatura[i] = valor_temp_fija[i]
        else:
            temperatura[i] = (H_k/2.0)*coorx[ndim-1][i]*(L - coorx[ndim-1][i]) - ((T0 - T_L)/L)*coorx[ndim-1][i] + T0

    for i in range(nelementos):
        print('Elemento {}: {}'.format(i, conectividad[i]))
    print('Temperaturas en los nodos: \n{}'.format(temperatura))
    
    fig, ax = plt.subplots()
    ax.plot(coorx[ndim-1], temperatura)

    plt.show()


    
