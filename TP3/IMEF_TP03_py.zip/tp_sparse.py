
import numpy as np
from mallado import mallador

def arma_sistema_sparse(ndim, nnod, nelem, nod_x_el, conect):

    naux = nnod

    ad = np.zeros((naux))
    ia = np.zeros((naux+1), dtype=int)
    nconta = np.zeros((naux), dtype=int)
    acum = np.zeros((naux), dtype=int)
    icx = np.zeros((naux), dtype=int)

    ia[0] = 1

    #COMPLETAR
    
    #COMPLETAR
    nonull = 

    an = np.zeros((nonull))

    return ad, an, ia, ja, icx

def arma_matriz_completa(ad, an, ia, ja, icx, ndim, nnod):

    k = np.zeros((nnod, nnod))

    #COMPLETAR

    return k


if __name__ == '__main__':
    
    ndim = 1
    nod_x_elem = 2
    nelementos = 4
    nnodos = (nod_x_elem-1)*nelementos+1
    L = 4.0
    H_k = 8.0
    T0 = 50.0
    T_L = 10.0

    coorx, conectividad, temp_fija, valor_temp_fija = mallador(nnodos, nelementos, nod_x_elem, L, T0, T_L)

    ad, an, ia, ja, icx = arma_sistema_sparse(ndim, nnodos, nelementos, nod_x_elem, conectividad)

    # VALORES DE EJEMPLO
    ad[0] = 1
    ad[1:nnodos-1] = 2
    ad[nnodos-1] = 1

    an[:-1] = -1

    # Matriz K como deberia ser, para referencia del resultado del ejercicio
    # SOLO PARA ELEMENTOS DE 2 NODOS
    k_aux = np.zeros((nnodos, nnodos))
    k_aux[0][0] = 1
    k_aux[0][1] = -1
    k_aux[nnodos-1][nnodos-2] = -1
    k_aux[nnodos-1][nnodos-1] = 1
    for i in range(nnodos-2):
        k_aux[i+1][i] = -1
        k_aux[i+1][i+1] = 2
        k_aux[i+1][i+2] = -1

    k = arma_matriz_completa(ad, an, ia, ja, icx, ndim, nnodos)

    print('Cantidad de nodos: \n{}'.format(nnodos))
    print('Dimension de la diagonal: \n{}'.format(len(ad)))
    
    print('\nCantidad de no nulos(+1): \n{}'.format(ia[-1]))
    print('Dimension de los valores no nulos fuera de la diagonal: \n{}'.format(len(an)))
    
    print('\nColumnas de no nulos: \n{}'.format(ja))
    print('Cantidad de no nulos por fila: \n{}'.format(icx))

    print('\nMatriz de rigidez teórica K: \n{}'.format(k_aux))

    print('\nMatriz de rigidez armada K: \n{}'.format(k))

    #print('\nIA: \n{}'.format(ia))
    #print('\nAN: \n{}'.format(an))