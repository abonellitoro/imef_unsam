function [coorx, conect, temp_fija, valor_temp_fija]=mallado(nnod, nelem, nod_x_elem, L, T0, T_L)

    %%%%%COMPLETAR!%%%%%%
end